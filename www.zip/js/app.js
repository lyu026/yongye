const App={
	config:{
		vu:'https://lyu026.github.io/yongye/',
		cv:localStorage.getItem('app_version')||'1.0.0',
		dd:'upgrade'
	},
	init:function(){
		const self=this
		document.addEventListener('deviceready',()=>{
			self.upgrade()
			//todo ...
		},false)
	},
	upgrade:function(){
		const self=this
		fetch(self.config.vu+'version.json?t='+Date.now()).then(_=>_.json()).then(o=>{
			if(o.version==self.config.cv)return
			if(!confirm('发现新版本，更新内容:\n\n'+o.message+'\n\n是否更新？'))return
			self._download(o.version)
		})
	},
	_download:function(version){
		const self=this
		cordova.plugins.Downloader.download({
			uri:self.config.vu+'www.zip',title:'雍也-更新',
			description:'正在下载最新版本...',
			visibleInDownloadsUi:true,
			destinationInExternalFilesDir:{dirType:'Download',subPath:version+'.zip'}
		},path=>self._unzip(path,version),err=>{
			alert('更新包下载失败，请检查网络')
		})
	},
	_unzip:function(path,version){
		const self=this
		if(!window.zip)return
		alert(path)
		window.zip.unzip(path,cordova.file.dataDirectory+self.config.dd+'/www/',o=>{
			if(o!=0)return alert('更新包解压失败')
			self._install(version)
		})
	},
	_install:function(version){
		const self=this
		localStorage.setItem('app_version',version)
		self.config.cv=version
		alert('更新完成，应用将重启加载新版本！')
		setTimeout(()=>window.location.reload(true),1000)
	}
}

App.init()