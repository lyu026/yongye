const OT={
	o:true,
	alert:function(title,text,fn,force=false){(this.o||force)&&navigator.notification.alert(text,fn,title,'关闭')||fn()},
	confirm:function(title,text,bs=[],force=false){(this.o||force)&&navigator.notification.confirm(text,i=>bs[i].todo(),title,bs.map(_=>_.name))||bs[1].todo()},
}

const App={
	start:function(){
		alert(`app. 欢迎进入主页`)
	}
}

document.addEventListener('deviceready',()=>App.start(),false)