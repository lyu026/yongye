class Downloader{
	constructor(){
		this.bs=0
		this.xhr=null
		this.wait=false
	}
	rdownload(url,name,ook,oer){
		window.requestFileSystem(LocalFileSystem.PERSISTENT,0,fs=>{
			window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory+'Download/',dir=>{
				dir.getFile(name,{create:false,exclusive:false},entry=>{
					entry.file(f=>{
						this.bs=f.size
						this.start(url,name,dir,ook,oer)
					})
				},()=>{
					this.bs=0
					this.start(url,name,dir,ook,oer)
				})
			})
		})
	}
	start(url,name,dir,ook,oer){
		this.xhr=new XMLHttpRequest()
		if(this.bs>0)this.xhr.setRequestHeader('Range',`bs=${this.bs}-`)
		this.xhr.open('GET',url,true)
		this.xhr.responseType='blob'
		this.xhr.onload=()=>{
			if(this.xhr.status===200||this.xhr.status===206){
				this.save(dir,name,this.xhr.response,this.bs>0,ook)
			}else{
				oer(`HTTP ${this.xhr.status}`)
			}
		}
		this.xhr.onerror=()=>oer('网络错误')
		this.xhr.send()
	}
	save(dir,name,data,isResume,ook){
		dir.getFile(name,{create:true,exclusive:false},entry=>{
			entry.createWriter(writer=>{
				if(isResume)writer.seek(writer.length)
				writer.onwriteend=()=>ook(entry.toURL())
				writer.write(data)
			})
		})
	}
	pause(){
		if(this.xhr){
			this.xhr.abort()
			this.wait=true
		}
	}
}

const O={
	config:{
		vu:'https://lyu026.github.io/yongye/',
		cv:localStorage.getItem('app_version')||'1.0.0',
	},
	upgrade:function(){
		const self=this
		fetch(self.config.vu+'version.json?t='+Date.now()).then(_=>_.json()).then(o=>{
			if(o.version==self.config.cv)return
			if(!confirm('发现新版本:'+o.version+'，更新内容:\n\n'+o.message+'\n\n是否更新？'))return
			self._download(o.version)
		})
	},
	_download:function(version){
		const self=this
		const downloader=new Downloader()
		downloader.rdownload(self.config.vu+'www.zip',version+'.zip',path=>{
			alert(path)
			self._unzip(path,version)
		},err=>{
			alert('下载失败：'+err)
		})
	},
	_unzip:function(path,version){
		const self=this
		if(!window.zip)return
		window.zip.unzip(path.replace('file://',''),cordova.file.dataDirectory.replace('file://','')+'www/',o=>{
			if(o!=0){
				alert('更新包解压失败')
				return
			}
			self._install(version)
		})
	},
	_install:function(version){
		const self=this
		localStorage.setItem('app_version',version)
		localStorage.setItem('new_www_ready','...')
		self.config.cv=version
		alert('更新完成，应用将重启加载新版本！')
		setTimeout(()=>{
			window.location.href='https://localhost/__cdvfile_files__/www/app.html?v='+Date.now()
		},400)
	}
}
O.upgrade()