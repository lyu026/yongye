window.onerror=(message,source,lineno,colno,error){
	alert("全局错误捕获: "+JSON.stringify({message,source,lineno,colno,error},null,2))
	return true
}

const OT={
	o:true,
	alert:function(title,text,fn,force=false){(this.o||force)&&navigator.notification.alert(text,fn,title,'关闭')||fn()},
	confirm:function(title,text,bs=[],force=false){(this.o||force)&&navigator.notification.confirm(text,i=>bs[i].todo(),title,bs.map(_=>_.name))||bs[1].todo()},
}

const App={
	start:function(){
		OT.alert(`主页`,`欢迎进入`,()=>{
			alert('asss')
		})
	}
}

document.addEventListener('deviceready',()=>App.start(),false)