
const App={
	start:function(){
		alert(`app. 欢迎进入主页`)
	}
}

document.addEventListener('deviceready',()=>App.start(),false)