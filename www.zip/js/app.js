const App={
	config:{
		vu:'https://lyu026.github.io/yongye/',
		cv:localStorage.getItem('app_version')||'1.0.0',
		dd:'upgrade'
	},
	init:function(){
		const self=this
		document.addEventListener('deviceready',()=>{
			self.upgrade()
			// todo ...
		},false)
	},
	upgrade:function(){
		const self=this
		fetch(self.config.vu+'version.json?t='+Date.now()).then(_=>_.json()).then(o=>{
			if(o.version==self.config.cv)return
			if(!confirm('发现新版本，是否更新？'))return
			self._download(o.version)
		})
	},
	_download:function(version){
		const self=this,transfer=new FileTransfer()
		window.resolveLocalFileSystemURL(cordova.file.dataDirectory,dir=>{
			dir.getDirectory(self.config.dd,{create:true},dd=>{
				const url=self.config.vu+'www.zip?t='+Date.now(),path=dd.toURL()+'www.zip'
				transfer.download(url,path,entry=>{
					self._unzip(entry.toURL(),version)
				},e=>{
					alert('更新下载失败，请检查网络');
				},true)
			})
		})
	},
	_unzip:function(path,version){
		const self=this
		if(!window.zip)return
		window.zip.unzip(path,cordova.file.dataDirectory+self.config.dd+'/www/',o=>{
			if(o!=0)return alert('更新包解压失败')
			self._install(version)
		})
	},
	_install:function(version){
		const self=this
		localStorage.setItem('app_version',version)
		self.config.cv=version
		alert('更新完成，应用将重启加载新版本！')
		setTimeout(()=>window.location.reload(true),1000);
	}
}

App.init()