window.onerror=(message,source,lineno,colno,error)=>{
	alert('全局错误捕获',JSON.stringify({message,source,lineno,colno,error},null,2))
	return true
}

const O={
	u:_=>`${_}?t=${Date.now()}`,
	c:(k,v)=>{
		if(v===undefined)return localStorage.getItem(k)
		localStorage.setItem(k,v)
	},
	cc:{url:'https://lyu026.github.io/yongye/',version:'1.0.0'},
	start:function(){
		const self=this
		self.cc.version=self.c('app_version')||'1.0.0'
		//alert(`1. 当前版本:${self.cc.version}\n\n开始获取最新版本号...`)
		fetch(self.u(self.cc.url+'version.json')).then(_=>_.json()).then(({version,message})=>{
			//alert(`1. 获取数据\n\n`+JSON.stringify({version,message},null,2))
			if(version==self.cc.version)return self._app()
			if(!confirm(`发现新版本:${version}\n\n更新内容:\n\n${message}\n\n是否更新？`))return self._app()
			self._fetch(version)
		}).catch(_=>{
			//alert(`1. 获取最新版本号失败\n\n`+_.message)
			self._app()
		})
	},
	_app:function(){
		if(this.c('new_www_ready')){
			window.location.href=this.u('https://localhost/__cdvfile_files__/www/app.html')
			return
		}
		window.location.href=this.u('app.html')
	},
	_fetch:function(version){
		const self=this
		//alert(`2. 开始拉取更新包\n\n版本号:${version}`)
		fetch(self.u(self.cc.url+'www.zip')).then(_=>_.blob()).then(blob=>{
			const dir=cordova.file.externalDataDirectory,name=version+'.zip'
			//alert(`2. 拉取成功\n\n目标目录：\n\n${dir}\n\n文件名:${name}`)
			window.resolveLocalFileSystemURL(dir+name,e=>{
				//alert(`2. 文件已存在,删除文件`)
				e.remove(()=>self._save(blob,dir,name,version),_=>self._save(blob,dir,name,version))
			},_=>{
				//alert(`2. 文件不存在,直接保存`)
				self._save(blob,dir,name,version)
			})
		}).catch(_=>{
			//alert(`2. 获取最新版本更新包失败\n\n`+_.message)
			self._app()
		})
	},
	_save:function(blob,dir,name,version){
		const self=this
		//alert(`3. 开始访问私有数据目录\n\n`+dir)
		window.resolveLocalFileSystemURL(dir,de=>{
			//alert(`3. 访问私有数据目录,访问成功`)
			de.getFile(name,{create:true,exclusive:false},fe=>{
				fe.createWriter(w=>{
					w.onwriteend=()=>{
						//alert(`3. 更新包保存成功\n\n`+fe.toURL())
						self._unzip(dir,name,version)
					}
					w.write(blob)
				},_=>self._app())
			},_=>self._app())
		},_=>self._app())
	},
	_unzip:function(dir,name,version){
		const self=this,td=cordova.file.dataDirectory.replace('file://','')
		//alert(`4. 开始解压缩更新包\n\n源:\n${dir.replace('file://','')+name}\n目标目录:\n${td+'www/'}`)
		window.zip.unzip(dir.replace('file://','')+name,td+'www/',o=>{
			if(o!=0){
				//alert('4. 更新包解压,失败')
				self._app()
				return
			}
			self.c('new_www_ready','...')
			self.c('app_version',self.cc.version=version)
			alert('更新完成','即将刷新页面加载新版本！')
			setTimeout(()=>self._app(),400)
		})
	}
}
document.addEventListener('deviceready',()=>O.start(),false)