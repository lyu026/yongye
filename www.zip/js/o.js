const OT=_=>O.cc.alert&&alert(_),O={
	u:_=>`${_}?t=${Date.now()}`,
	c:(k,v)=>{
		if(v===undefined)return localStorage.getItem(k)
		localStorage.setItem(k,v)
	},
	cc:{alert:false,url:'https://lyu026.github.io/yongye/',version:'1.0.0'},
	start:function(){
		const self=this
		self.cc.version=self.c('app_version')||'1.0.0'
		OT(`1. 当前版本: ${self.cc.version}，开始获取最新版本号...`)
		fetch(self.u(self.cc.url+'version.json')).then(_=>_.json()).then(({version,message})=>{
			OT(`1. 获取数据: ${JSON.stringify({version,message})}`)
			if(version==self.cc.version)return self._app()
			if(!confirm(`发现新版本:${version}，更新内容:\n\n${message}\n\n是否更新？`))return self._app()
			self._fetch(version)
		}).catch(_=>{
			OT(`1. 获取最新版本号失败，${_.message}`)
			self._app()
		})
	},
	_app:function(){
		if(this.c('new_www_ready')){
			window.location.href=this.u('https://localhost/__cdvfile_files__/www/app.html')
			return
		}
		window.location.href=this.u('app.html')
	},
	_fetch:function(version){
		const self=this
		OT(`2. 开始拉取更新包，版本号:${version}`)
		fetch(self.u(self.cc.url+'www.zip')).then(_=>_.blob()).then(blob=>{
			const dir=cordova.file.externalDataDirectory,name=version+'.zip'
			OT(`2. 拉取成功，目标目录：\n\n${dir}\n, 文件名: ${name}`)
			window.resolveLocalFileSystemURL(dir+name,e=>{
				OT(`2. 文件已存在，删除文件`)
				e.remove(()=>self._save(blob,dir,name,version),_=>self._save(blob,dir,name,version))
			},_=>{
				OT(`2. 文件不存在，直接保存`)
				self._save(blob,dir,name,version)
			})
		}).catch(_=>{
			OT(`2. 获取最新版本更新包失败，${_.message}`)
			self._app()
		})
	},
	_save:function(blob,dir,name,version){
		const self=this
		OT(`3. 开始访问私有数据目录:\n${dir}`)
		window.resolveLocalFileSystemURL(dir,de=>{
			OT(`3. 私有数据目录访问成功`)
			de.getFile(name,{create:true,exclusive:false},fe=>{
				OT(`3. 更新包保存到私有数据目录`)
				fe.createWriter(w=>{
					w.onwriteend=()=>{
						OT(`3. 更新包保存成功:\n${fe.toURL()}`)
						self._unzip(dir,name,version)
					}
					w.write(blob)
				},_=>self._app())
			},_=>self._app())
		},_=>self._app())
	},
	_unzip:function(dir,name,version){
		const self=this,td=cordova.file.dataDirectory.replace('file://','')
		OT(`4. 开始解压缩更新包，源:\n${dir.replace('file://','')+name}\n目标目录:\n${td+'www/'}`)
		window.zip.unzip(dir.replace('file://','')+name,td+'www/',o=>{
			if(o!=0){
				OT('4. 更新包解压失败')
				return self._app()
			}
			self.c('new_www_ready','...')
			self.c('app_version',self.cc.version=version)
			alert('更新完成，应用将刷新页面加载新版本！')
			setTimeout(()=>self._app(),400)
		})
	}
}
document.addEventListener('deviceready',()=>O.start(),false)