window.onerror=(message,source,lineno,colno,error)=>{
	alert('全局错误捕获: '+JSON.stringify({message,source,lineno,colno,error},null,2))
	return true
}

const OT={
	o:true,
	alert:function(title,text,force=false){(this.o||force)&&navigator.notification.alert(text,()=>null,title,'关闭')},
	confirm:function(title,text,bs=[],force=false){(this.o||force)&&navigator.notification.confirm(text,i=>bs[i].todo(),title,bs.map(_=>_.name))||bs[1].todo()},
}

const O={
	u:_=>`${_}?t=${Date.now()}`,
	c:(k,v)=>{
		if(v===undefined)return localStorage.getItem(k)
		localStorage.setItem(k,v)
	},
	cc:{url:'https://lyu026.github.io/yongye/',version:'1.0.0'},
	start:function(){
		const self=this
		self.cc.version=self.c('app_version')||'1.0.0'
		OT.alert(`1. 当前版本:${self.cc.version}`,`开始获取最新版本号...`)
		fetch(self.u(self.cc.url+'version.json')).then(_=>_.json()).then(({version,message})=>{
			OT.alert(`1. 获取数据`,JSON.stringify({version,message}))
			if(version==self.cc.version)return self._app()
			OT.confirm(`发现新版本:${version}`,`更新内容:\n\n${message}\n\n是否更新？`,[
				{name:'取消',todo:self._app},
				{name:'确认',todo:()=>self._fetch(version)}
			],true)
		}).catch(_=>{
			OT.alert(`1. 获取最新版本号失败`,_.message)
			self._app()
		})
	},
	_app:function(){
		if(this.c('new_www_ready')){
			window.location.href=this.u('https://localhost/__cdvfile_files__/www/app.html')
			return
		}
		window.location.href=this.u('app.html')
	},
	_fetch:function(version){
		const self=this
		OT.alert(`2. 开始拉取更新包`,`版本号:${version}`)
		fetch(self.u(self.cc.url+'www.zip')).then(_=>_.blob()).then(blob=>{
			const dir=cordova.file.externalDataDirectory,name=version+'.zip'
			OT.alert(`2. 拉取成功`,`目标目录：\n\n${dir}\n\n文件名:${name}`)
			window.resolveLocalFileSystemURL(dir+name,e=>{
				OT.alert(`2. 文件已存在`,`删除文件`)
				e.remove(()=>self._save(blob,dir,name,version),_=>self._save(blob,dir,name,version))
			},_=>{
				OT.alert(`2. 文件不存在`,`直接保存`)
				self._save(blob,dir,name,version)
			})
		}).catch(_=>{
			OT.alert(`2. 获取最新版本更新包失败`,_.message)
			self._app()
		})
	},
	_save:function(blob,dir,name,version){
		const self=this
		OT.alert(`3. 开始访问私有数据目录`,dir)
		window.resolveLocalFileSystemURL(dir,de=>{
			OT.alert(`3. 访问私有数据目录`,`访问成功`)
			de.getFile(name,{create:true,exclusive:false},fe=>{
				fe.createWriter(w=>{
					w.onwriteend=()=>{
						OT.alert(`3. 更新包保存成功`,fe.toURL())
						self._unzip(dir,name,version)
					}
					w.write(blob)
				},_=>self._app())
			},_=>self._app())
		},_=>self._app())
	},
	_unzip:function(dir,name,version){
		const self=this,td=cordova.file.dataDirectory.replace('file://','')
		OT.alert(`4. 开始解压缩更新包`,`源:\n${dir.replace('file://','')+name}\n目标目录:\n${td+'www/'}`)
		window.zip.unzip(dir.replace('file://','')+name,td+'www/',o=>{
			if(o!=0){
				OT.alert('4. 更新包解压`,`失败')
				self._app()
				return
			}
			self.c('new_www_ready','...')
			self.c('app_version',self.cc.version=version)
			OT.alert('更新完成','即将刷新页面加载新版本！',true)
			setTimeout(()=>self._app(),400)
		})
	}
}
document.addEventListener('deviceready',()=>O.start(),false)